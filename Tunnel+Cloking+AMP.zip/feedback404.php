<?php

if (!function_exists('feedback404')) {

    function feedback404($message = '404 - Halaman Tidak Ditemukan')
    {
        // ini Jika WordPress aktif
        if (function_exists('status_header') && function_exists('get_404_template')) {

            global $wp_query;

            if (isset($wp_query)) {
                $wp_query->set_404();
            }

            status_header(404);
            nocache_headers();

            $template = get_404_template();

            if ($template) {
                include $template;
                exit;
            }
        }

        // Ini PHP biasa
        http_response_code(404);

        if (file_exists(__DIR__.'/404.php')) {
            include __DIR__.'/404.php';
        } else {
            echo '<h1>404 Not Found</h1>';
        }

        exit();
    }

}