<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../feedback404.php';

$file = __DIR__ . '/../brands.json';

if (!file_exists($file)) {
    die('brands.json tidak ditemukan');
}

$data = json_decode(file_get_contents($file), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    die('JSON Error: ' . json_last_error_msg());
}
$key = strtolower(trim($_GET['kelas'] ?? ''));

if (!$key || !isset($data[$key])) {
    feedback404();
}
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host   = $_SERVER['HTTP_HOST'];

$item = $data[$key];

$BRAND       = $item['brand'] ?? '';
$TITLE       = $item['title'] ?? '';
$KEYWORD     = $item['keyword'] ?? '';
$DESCRIPTION = $item['description'] ?? '';
$LOGO          = $data[$key]['logo'] ?? '';
$IMAGE       = $item['image'] ?? '';
$LINK_DAFTAR       = $item['link_daftar'] ?? ''; //LINK YANG TERSITE
$THEME_COLOR   = $data[$key]['theme_color'] ?? '#6621ba';

$CANONICAL = $scheme . '://' . $host . '/jack/index.php?kelas=' . urlencode($key);

?>


<!DOCTYPE html>
<html amp lang="id-ID">
<head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($BRAND . ' | ' . $TITLE, ENT_QUOTES, 'UTF-8') ?></title>
<meta name="description" content="<?= htmlspecialchars($DESCRIPTION) ?>">
<link rel="canonical" href="<?= htmlspecialchars($CANONICAL) ?>">
<link rel="alternate" href="<?= htmlspecialchars($CANONICAL) ?>" hreflang="id"/>
<meta property="og:url" content="<?= htmlspecialchars($CANONICAL) ?>"/>
<meta property="og:title" content="<?= htmlspecialchars($BRAND . ' | ' . $TITLE, ENT_QUOTES, 'UTF-8') ?>"/>
<meta property="og:description" content="<?= htmlspecialchars($DESCRIPTION) ?>"/>
<meta property="og:image" content="<?= htmlspecialchars($IMAGE) ?>"/>
<meta property="og:type" content="website"/>
<meta property="og:site_name" content="<?= htmlspecialchars($BRAND) ?>"> 
<meta property="og:locale" content="id_ID">
<link rel="shortcut icon" href="https://www.gstatic.com/images/branding/searchlogo/ico/favicon.ico">
<link rel="icon" type="image/png" href="https://www.gstatic.com/images/branding/searchlogo/ico/favicon.ico">
<link rel="apple-touch-icon" href="https://www.gstatic.com/images/branding/searchlogo/ico/favicon.ico">
<meta name="theme-color" content="<?= htmlspecialchars($THEME_COLOR) ?>">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="robots" content="index, follow">
<meta name="rating" content="general">
<meta name="geo.region" content="ID-JK"/>
<meta name="geo.placename" content="Jakarta ID Indonesia"/>
<meta name="language" content="Indonesia">
<meta name="tgn.nation" content="Indonesia">
<meta name="distribution" content="global">
<meta name="publisher" content="<?= htmlspecialchars($BRAND) ?>">
<meta name="dc.Publisher" content="<?= htmlspecialchars($BRAND) ?>">
<meta name="dc.language" content="id,en">
<meta name="owner" content="<?= htmlspecialchars($BRAND) ?>">
<meta name="googlebot" content="index,follow">
<meta name="MSSmartTagsPreventParsing" content="true">
<meta name="audience" content="all">
<link rel="preconnect" href="https://cdn.ampproject.org">
<link rel="preload" as="script" href="https://cdn.ampproject.org/v0.js">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@400;600;700&display=swap">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<link rel="preload" href="https://i.ibb.co.com/JWfn6b1q/<?= htmlspecialchars($BRAND) ?>.png" as="image">
<style amp-custom>
*,:after,:before{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{min-height:100vh;min-width:320px;overflow-x:hidden;font-family:'Rajdhani',sans-serif;background:#1a1200;color:#fff8dc;letter-spacing:.01em;line-height:1}
a{color:inherit;text-decoration:none;transition:all .3s ease}
:root{
  --bg: #03102c; 
  --surface: rgba(10, 31, 68, 0.75); 
  --surface-s: rgba(20, 50, 100, 0.85); 
  
  --primary: #007bff; 
  --accent: #ffb800; 
  --deep: #d4af37; 
  --dark: #ffd700; 
  --hot: #fffdf5; 
  --ice: #e6f7ff; 
  
  --text: #ffffff; 
  --text-s: #d4e3ff;
  --text-d: #f4c430;
  
  --glass: linear-gradient(180deg, rgba(20, 50, 100, 0.75), rgba(10, 31, 68, 0.65)); 
  --glass-s: linear-gradient(180deg, rgba(30, 60, 110, 0.84), rgba(15, 36, 75, 0.78));
  
  --gborder: rgba(0, 123, 255, 0.4); 
  --ghl: rgba(255, 255, 255, 0.08); 
  
  --shadow: 0 10px 35px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(0, 123, 255, 0.15) inset, 0 0 20px rgba(0, 123, 255, 0.15), 0 0 50px rgba(212, 175, 55, 0.12); 
  --glow: 0 0 18px rgba(0, 123, 255, 0.4), 0 0 45px rgba(0, 123, 255, 0.2), 0 0 80px rgba(212, 175, 55, 0.15);
  --glow-s: 0 0 10px rgba(0, 123, 255, 0.35), 0 0 20px rgba(212, 175, 55, 0.18); 
  --tglow: 0 0 8px rgba(0, 123, 255, 0.8), 0 0 18px rgba(0, 123, 255, 0.5), 0 0 34px rgba(212, 175, 55, 0.25); 
}
#world {
  position: relative;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: radial-gradient(ellipse 55% 45% at 10% 10%, rgba(138, 43, 226, .12) 0, transparent 22%),
              radial-gradient(ellipse 50% 40% at 88% 25%, rgba(65, 105, 225, .10) 0, transparent 22%),
              radial-gradient(ellipse 45% 45% at 50% 95%, rgba(212, 175, 55, .08) 0, transparent 25%),
              linear-gradient(180deg, #0d001a 0%, #140026 40%, #0a0014 70%, #0d001a 100%);
  overflow: hidden
}

#world::before {
  content: '';
  position: fixed;
  inset: 0;
  background: linear-gradient(130deg, transparent 0%, rgba(255, 255, 255, .015) 28%, transparent 48%),
              linear-gradient(310deg, transparent 0%, rgba(138, 43, 226, .015) 34%, transparent 58%);
  pointer-events: none;
  z-index: 0
}

.smoke {
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
  z-index: 0;
  opacity: .9
}

.smoke.s1 {
  width: 350px;
  height: 250px;
  border-radius: 40% 60% 55% 45%;
  background: radial-gradient(ellipse, rgba(138, 43, 226, .18), transparent 65%);
  filter: blur(60px);
  top: -40px;
  left: -80px;
  animation: sFloat 14s ease-in-out infinite alternate
}

.smoke.s2 {
  width: 300px;
  height: 220px;
  border-radius: 55% 45% 50% 50%;
  background: radial-gradient(ellipse, rgba(65, 105, 225, .15), transparent 65%);
  filter: blur(55px);
  top: 40%;
  right: -90px;
  animation: sFloat2 18s ease-in-out infinite alternate
}

.smoke.s3 {
  width: 200px;
  height: 200px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(212, 175, 55, .12), transparent 68%);
  filter: blur(50px);
  bottom: 5%;
  left: 20%;
  animation: sFloat 12s ease-in-out infinite alternate
}

@keyframes sFloat {
  from { transform: translate(0, 0) rotate(0deg) scale(1) }
  to { transform: translate(30px, 20px) rotate(8deg) scale(1.1) }
}

@keyframes sFloat2 {
  from { transform: translate(0, 0) rotate(0deg) scale(1) }
  to { transform: translate(-25px, 15px) rotate(-5deg) scale(1.08) }
}
.hexgrid {
  position: fixed;
  inset: 0;
  background-image: linear-gradient(30deg, rgba(0, 123, 255, 0.04) 12%, transparent 12.5%, transparent 87%, rgba(0, 123, 255, 0.04) 87.5%, rgba(0, 123, 255, 0.04)),
                    linear-gradient(150deg, rgba(0, 123, 255, 0.04) 12%, transparent 12.5%, transparent 87%, rgba(0, 123, 255, 0.04) 87.5%, rgba(0, 123, 255, 0.04)),
                    linear-gradient(30deg, rgba(0, 123, 255, 0.04) 12%, transparent 12.5%, transparent 87%, rgba(0, 123, 255, 0.04) 87.5%, rgba(0, 123, 255, 0.04)),
                    linear-gradient(150deg, rgba(0, 123, 255, 0.04) 12%, transparent 12.5%, transparent 87%, rgba(0, 123, 255, 0.04) 87.5%, rgba(0, 123, 255, 0.04));
  background-size: 60px 104px;
  background-position: 0 0, 0 0, 30px 52px, 30px 52px;
  pointer-events: none;
  z-index: 0;
  mask-image: linear-gradient(180deg, rgba(0, 0, 0, .15), rgba(0, 0, 0, .5))
}

.vignette {
  position: fixed;
  inset: 0;
  background: radial-gradient(ellipse 70% 70% at 50% 50%, transparent 50%, rgba(3, 16, 44, .7) 100%);
  pointer-events: none;
  z-index: 1
}

.embers {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 0
}

.embers::before {
  content: '';
  position: absolute;
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: var(--primary);
  box-shadow: 18vw 12vh 0 0 rgba(212, 175, 55, .35), 
              72vw 8vh 0 1px rgba(0, 123, 255, .25), 
              35vw 55vh 0 0 rgba(0, 123, 255, .30), 
              88vw 42vh 0 1px rgba(212, 175, 55, .25), 
              55vw 78vh 0 0 rgba(0, 123, 255, .30), 
              8vw 68vh 0 1px rgba(0, 123, 255, .20), 
              62vw 22vh 0 0 rgba(212, 175, 55, .28), 
              42vw 92vh 0 0 rgba(0, 123, 255, .22), 
              92vw 75vh 0 1px rgba(0, 123, 255, .25);
  animation: emberDrift 25s ease-in-out infinite alternate
}

@keyframes emberDrift {
  0% { transform: translateY(0) }
  50% { transform: translateY(-12px) }
  100% { transform: translateY(5px) }
}

#content {
  position: relative;
  z-index: 2;
  width: 100%;
  max-width: 460px;
  padding: 0 1.2rem 2.5rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.2rem
}

.topbar {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.2rem 0 0;
  gap: .8rem
}

.logo-hex {
  position: relative;
  padding: 6px;
  display: inline-flex
}

.logo-hex::before {
  content: '';
  position: absolute;
  inset: -4px;
  border-radius: 14px;
  background: linear-gradient(135deg, rgba(0, 123, 255, .4), rgba(0, 123, 255, .2), rgba(212, 175, 55, .3));
  filter: blur(8px);
  opacity: .8;
  animation: logoBreath 3s ease-in-out infinite alternate
}

.logo-hex::after {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: 12px;
  border: 1px solid rgba(0, 123, 255, .35);
  pointer-events: none
}

@keyframes logoBreath {
  from { opacity: .5; transform: scale(.98) }
  to { opacity: 1; transform: scale(1.02) }
}

.logo-inner {
  display: block;
  border-radius: 10px;
  overflow: hidden;
  border: 1px solid rgba(0, 123, 255, .4);
  background: rgba(10, 31, 68, .6);
  backdrop-filter: blur(10px);
  box-shadow: var(--shadow)
}

.live-pill {
  display: flex;
  align-items: center;
  gap: .5rem;
  background: rgba(10, 31, 68, .65);
  border: 1px solid rgba(0, 123, 255, .3);
  border-radius: 999px;
  padding: .4rem .9rem;
  font-family: 'Orbitron', monospace;
  font-size: 9px;
  font-weight: 700;
  letter-spacing: .14em;
  color: var(--ice);
  text-transform: uppercase;
  backdrop-filter: blur(10px);
  box-shadow: var(--glow-s)
}

.live-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #00e5ff;
  box-shadow: 0 0 8px #00e5ff, 0 0 16px #00e5ff;
  animation: ldot 1.4s ease-in-out infinite
}

@keyframes ldot {
  0%, 100% { opacity: 1; transform: scale(1) }
  50% { opacity: .3; transform: scale(.8) }
}

.neon-line {
  width: 100%;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--primary), var(--accent), var(--primary), transparent);
  box-shadow: 0 0 12px rgba(0, 123, 255, .6);
  animation: linePulse 3s ease-in-out infinite
}

@keyframes linePulse {
  0%, 100% { opacity: .4 }
  50% { opacity: 1 }
}

.hero-title {
  font-family: 'Orbitron', monospace;
  font-size: clamp(13px, 3.8vw, 16px);
  font-weight: 900;
  letter-spacing: .10em;
  text-align: center;
  color: var(--hot);
  text-shadow: var(--tglow);
  line-height: 1.5;
  text-transform: uppercase;
  animation: titlePulse 4.5s ease-in-out infinite
}

@keyframes titlePulse {
  0%, 100% { text-shadow: 0 0 8px rgba(0, 123, 255, .6), 0 0 18px rgba(0, 123, 255, .3), 0 0 30px rgba(212, 175, 55, .2) }
  50% { text-shadow: 0 0 12px rgba(0, 123, 255, 1), 0 0 28px rgba(0, 123, 255, .5), 0 0 50px rgba(212, 175, 55, .4) }
}

.banner-wrap {
  width: 100%;
  position: relative;
  border-radius: 16px;
  overflow: hidden;
  /* MENAMBAHKAN: Border putih solid 1px */
  border: 1px solid #ffffff; 
  background: var(--glass);
  backdrop-filter: blur(10px);
  /* MENGUBAH: box-shadow untuk efek glow putih tambahan */
  box-shadow: 
    var(--shadow), /* bayangan dasar */
    var(--glow),   /* glow biru asli Anda */
    0 0 12px rgba(255, 255, 255, 0.45); /* glow putih lembut baru */
}

/* Pseudo-element ::before untuk efek 'sweep' cahaya asli Anda */
.banner-wrap::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 50%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, .12), rgba(0, 123, 255, .1), transparent);
  animation: bsweep 6s ease-in-out infinite;
  z-index: 2;
  pointer-events: none
}


@keyframes bsweep {
  0% { left: -100% }
  55%, 100% { left: 150% }
}

.banner-wrap::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(255, 255, 255, .05), transparent 15%, transparent 85%, rgba(0, 123, 255, .08));
  pointer-events: none;
  z-index: 1
}

.blade { position: absolute; z-index: 3; pointer-events: none }
.blade.tl { top: 6px; left: 6px; width: 22px; height: 22px; border-top: 2px solid var(--primary); border-left: 2px solid var(--primary); box-shadow: -2px -2px 14px rgba(0, 123, 255, .6) }
.blade.tr { top: 6px; right: 6px; width: 22px; height: 22px; border-top: 2px solid var(--primary); border-right: 2px solid var(--primary); box-shadow: 2px -2px 14px rgba(0, 123, 255, .6) }
.blade.bl { bottom: 6px; left: 6px; width: 22px; height: 22px; border-bottom: 2px solid var(--primary); border-left: 2px solid var(--primary); box-shadow: -2px 2px 14px rgba(0, 123, 255, .6) }
.blade.br { bottom: 6px; right: 6px; width: 22px; height: 22px; border-bottom: 2px solid var(--primary); border-right: 2px solid var(--primary); box-shadow: 2px 2px 14px rgba(0, 123, 255, .6) }
.stat-strip {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 6px;
  width: calc(100% - 24px);
  margin-top: 10px;
  position: relative;
  z-index: 4
}
.stat-box {
  background: var(--glass-s);
  border: 1px solid var(--gborder);
  border-radius: 12px;
  padding: .7rem .4rem;
  text-align: center;
  backdrop-filter: blur(16px);
  position: relative;
  overflow: hidden;
  box-shadow: var(--shadow)
}

.stat-box::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--primary), transparent);
  box-shadow: 0 0 10px rgba(0, 123, 255, .6) /* Mengubah pendaran garis atas menjadi biru */
}

.stat-box::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(255, 255, 255, .04), transparent 30%);
  pointer-events: none
}

.stat-val {
  display: block;
  font-family: 'Orbitron', monospace;
  font-size: 11px;
  font-weight: 700;
  color: var(--ice);
  text-shadow: 0 0 8px rgba(0, 123, 255, .6); /* Mengubah pendaran nilai statistik menjadi biru royal */
  line-height: 1;
  margin-bottom: .3rem
}

.stat-lbl {
  display: block;
  font-size: 10px;
  color: var(--text-s);
  letter-spacing: .12em;
  text-transform: uppercase;
  font-family: 'Orbitron', monospace;
  line-height: 1.3
}

.cta-row { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; width: 100% }

.cta {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .6rem;
  min-height: 3.4rem;
  border-radius: 14px;
  font-family: 'Orbitron', monospace;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: .12em;
  text-transform: uppercase;
  text-decoration: none;
  position: relative;
  overflow: hidden;
  transition: transform .25s, box-shadow .25s;
  backdrop-filter: blur(12px)
}

.cta:active { transform: scale(.97) }

.cta::before {
  content: '';
  position: absolute;
  top: 0;
  left: -120%;
  width: 40%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, .25), transparent);
  transform: skewX(-18deg);
  animation: csweep 3.5s ease-in-out infinite
}

@keyframes csweep {
  0% { left: -120% }
  55%, 100% { left: 145% }
}

/* Mengubah Tombol CTA Utama menjadi gradien Biru Gelap ke Emas-VIP dengan pendaran Biru Royal super mewah */
.cta-primary {
  background: linear-gradient(135deg, rgba(10, 31, 68, 0.95), rgb(212, 175, 55) 40%, rgba(0, 123, 255, 0.95));
  background-size: 220% 220%;
  color: #fff;
  font-weight: 800;
  border: 1px solid rgba(255, 255, 255, .25);
  box-shadow: 0 8px 24px rgba(0, 0, 0, .4), 
              0 0 18px rgba(0, 123, 255, .5), 
              0 0 40px rgba(0, 123, 255, .3), 
              inset 0 1px 0 rgba(255, 255, 255, .3);
  animation: ctaFlow 4s ease infinite
}

@keyframes ctaFlow {
  0% { background-position: 0% 50% }
  50% { background-position: 100% 50% }
  100% { background-position: 0% 50% }
}

.cta-secondary {
  background: var(--glass-s);
  color: var(--text);
  border: 1px solid var(--gborder);
  box-shadow: 0 8px 20px rgba(0, 0, 0, .25), 0 0 12px rgba(0, 123, 255, .15), inset 0 1px 0 var(--ghl)
}

.cta-secondary::before { animation-delay: 1.5s }

.cta:hover {
  box-shadow: 0 10px 28px rgba(0, 0, 0, .35), 0 0 22px rgba(0, 123, 255, .6), 0 0 48px rgba(0, 123, 255, .4);
  transform: translateY(-2px)
}

.cta-ico { width: 1.1rem; height: 1.1rem; flex-shrink: 0 }

/* Mengubah desain alt-pill (alternatif) dengan latar belakang & garis putus-putus biru transparan */
.alt-pill {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .6rem;
  width: 100%;
  padding: .85rem;
  background: rgba(10, 31, 68, .5);
  border: 1px dashed rgba(0, 123, 255, .35);
  border-radius: 12px;
  font-family: 'Orbitron', monospace;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--text-s);
  transition: all .3s
}

.alt-pill:hover {
  border-style: solid;
  border-color: rgba(0, 123, 255, .6);
  color: var(--ice);
  box-shadow: 0 0 15px rgba(0, 123, 255, .3)
}

.alt-pill svg { width: 14px; height: 14px; stroke: currentColor; fill: none; stroke-width: 2; stroke-linecap: round }

.divider { width: 100%; display: flex; align-items: center; gap: .7rem }

/* Mengubah garis pembagi dibuat bersinar dengan warna biru-emas */
.div-line {
  flex: 1;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(0, 123, 255, .4), transparent);
  box-shadow: 0 0 10px rgba(0, 123, 255, .2)
}

.div-text {
  font-family: 'Orbitron', monospace;
  font-size: 9px;
  letter-spacing: .2em;
  color: var(--text-d);
  text-transform: uppercase
}

.cards { width: 100%; display: flex; flex-direction: column; gap: .65rem }

.card {
  display: flex;
  align-items: center;
  gap: .85rem;
  background: var(--glass-s);
  border: 1px solid var(--gborder);
  border-radius: 16px;
  padding: .9rem 1rem;
  position: relative;
  overflow: hidden;
  backdrop-filter: blur(12px);
  box-shadow: var(--shadow);
  transition: border-color .3s, transform .3s
}

.card:hover {
  border-color: rgba(0, 123, 255, .5);
  transform: translateY(-2px)
}

/* Mengubah bar penanda vertikal di kiri kartu menjadi gradien Biru-Emas sesuai tema */
.card::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 3px;
  background: linear-gradient(180deg, var(--primary), var(--accent), var(--deep));
  box-shadow: 0 0 10px rgba(0, 123, 255, .6)
}

.card::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(255, 255, 255, .035), transparent 30%);
  pointer-events: none
}

/* Kotak icon kartu diubah menjadi latar belakang biru transparan */
.card-icon {
  width: 2.2rem;
  height: 2.2rem;
  border-radius: 10px;
  background: linear-gradient(180deg, rgba(0, 123, 255, .2), rgba(0, 123, 255, .05));
  border: 1px solid rgba(0, 123, 255, .3);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 0 12px rgba(0, 123, 255, .15), inset 0 1px 0 rgba(255, 255, 255, .08)
}

.card-icon svg {
  width: 1rem;
  height: 1rem;
  fill: var(--ice);
  filter: drop-shadow(0 0 6px rgba(0, 123, 255, .5))
}

.card-text { flex: 1; min-width: 0 }
.card-name { font-family: 'Orbitron', monospace; font-size: 11px; font-weight: 700; color: var(--hot); letter-spacing: .08em; text-transform: uppercase; margin-bottom: .2rem; line-height: 1.3 }
.card-desc { font-size: 10px; color: var(--text-s); line-height: 1.5 }

/* Badge kartu diubah menjadi kontainer biru gelap mewah dengan border biru elektrik */
.card-badge {
  font-family: 'Orbitron', monospace;
  font-size: 9px;
  font-weight: 700;
  letter-spacing: .1em;
  color: var(--ice);
  background: linear-gradient(180deg, rgba(10, 31, 68, .92), rgba(3, 16, 44, .85));
  border: 1px solid rgba(0, 123, 255, .3);
  border-radius: 6px;
  padding: .22rem .44rem;
  white-space: nowrap;
  text-transform: uppercase;
  flex-shrink: 0;
  box-shadow: 0 0 10px rgba(0, 123, 255, .1)
}

.trust-wrap {
  width: 100%;
  display: flex;
  justify-content: center;
  border-radius: 12px;
  overflow: hidden;
  border: 1px solid var(--gborder);
  box-shadow: 0 0 15px rgba(0, 123, 255, .15)
}

.foot { width: 100%; text-align: center; padding: .5rem 0 0 }
.foot p { font-family: 'Orbitron', monospace; font-size: 10px; color: var(--text-d); letter-spacing: .14em; text-transform: uppercase; text-shadow: 0 0 8px rgba(0, 123, 255, .15) }
.foot .sig { display: block; margin-top: 5px; font-size: 7px; letter-spacing: 3px; opacity: .2 }

/* Marquee teks berjalan diubah latarnya menjadi hitam-biru gelap dengan border bawah emas/kuning */
.top-marquee {
  width: 100%;
  background: rgba(3, 16, 44, 0.95);
  border-bottom: 2px solid var(--accent);
  overflow: hidden;
  padding: 16px 0;
  position: relative;
  z-index: 10;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.8)
}

.tm-track { display: flex; width: fit-content; animation: tscroll 50s linear infinite }

/* Efek pendaran teks marquee diubah menjadi biru elektrik menyala agar kontras dan tajam */
.tm-item {
  display: inline-flex;
  align-items: center;
  padding: 0 3rem;
  font-size: 14px;
  font-family: 'Orbitron', sans-serif;
  font-weight: 900;
  color: #fff;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  text-shadow: 0 0 15px rgba(0, 123, 255, 0.8);
  white-space: nowrap
}
@keyframes tscroll{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
@media(max-width:360px){.hero-title{font-size:12px}.cta{font-size:11px}.cta-row{grid-template-columns:1fr;gap:6px}.stat-strip{grid-template-columns:1fr 1fr 1fr}}
</style>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style>
<noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
</head>
<body>
<div class="top-marquee">
  <div class="tm-track">
    <span class="tm-item">✦🔥 <?= htmlspecialchars($BRAND) ?> SITUS RESMI SCATTER HITAM SPESIAL 2026 🔥✦</span>
    <span class="tm-item">✦🔥 WAJIB MEMBER BARU PASTI WEDE COK! 🔥✦</span>
    <span class="tm-item">✦🔥 AKUN BARU LANGSUNG PECHAH SEKARANG JUGA 🔥✦</span>
    <span class="tm-item">✦🔥 PROSES DEPOSIT & WITHDRAW TERCEPAT 24 JAM NONSTOP 🔥✦</span>
  </div>
</div>

<!-- SVG Symbols -->
<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" hidden>
  <symbol id="i-pad" viewBox="0 0 40 40"><path d="M36.3,32.1c-2.6,0.7-5.5-0.9-6.8-3.5l-2.9-6.2H20h-6.6l-2.9,6.2c-1.2,2.6-4.1,4.2-6.8,3.5c-2.6-0.7-4.2-3.4-3.5-6L2,19.3C2,19.2,2,19.1,2.1,19l1.5-5.8c0.8-3,3.9-5.4,6.9-5.4H20h9.5c3,0,6.1,2.4,6.9,5.4l1.5,5.8c0,0.1,0.1,0.2,0.1,0.3l1.8,6.8C40.5,28.7,39,31.4,36.3,32.1z"/></symbol>
  <symbol id="i-user" viewBox="0 0 40 40"><path d="M31.6,36.5H8.4c-1.7,0-3.1-1.4-3.1-3.1v-4.6c0-3.8,1.8-6.9,5.2-9c1.1-0.7,2.4-1.2,3.8-1.6c-0.8-0.7-1.5-1.5-2-2.4c-0.8-1.3-1.2-2.9-1.2-4.4c0-4.9,4-8.9,8.9-8.9s8.9,4,8.9,8.9c0,1.6-0.4,3.1-1.2,4.4c-0.5,0.9-1.2,1.7-2,2.4c1.4,0.4,2.7,1,3.8,1.6c3.4,2,5.2,5.1,5.2,9v4.6C34.7,35.1,33.3,36.5,31.6,36.5z"/></symbol>
  <symbol id="i-shield" viewBox="0 0 40 40"><path d="M20 3L5 9v10c0 9.4 6.4 18.2 15 21 8.6-2.8 15-11.6 15-21V9L20 3zm-2 26l-6-6 2.1-2.1L18 24.8l9.9-9.9 2.1 2.1L18 29z"/></symbol>
  <symbol id="i-bolt" viewBox="0 0 40 40"><path d="M22 2L8 22h12l-2 16 14-20H20L22 2z"/></symbol>
</svg>

<div id="world">
  <!-- Decorative layers -->
  <div class="smoke s1"></div>
  <div class="smoke s2"></div>
  <div class="smoke s3"></div>
  <div class="hexgrid"></div>
  <div class="vignette"></div>
  <div class="embers"></div>

  <div id="content">
  
    <!-- TOP BAR: Logo + Live -->
    <div class="topbar">
      <a href="<?= htmlspecialchars($CANONICAL) ?>" class="logo-hex">
        <span class="logo-inner">
          <amp-img src="<?= htmlspecialchars($LOGO) ?>"
                   alt="LOGO <?= htmlspecialchars($BRAND) ?>" width="180" height="80" layout="fixed"></amp-img>
        </span>
      </a>
      <div class="live-pill">
        <span class="live-dot"></span>
        Online 24/7
      </div>
    </div>

    <!-- NEON LINE -->
    <div class="neon-line"></div>

    <!-- HERO TITLE -->
    <h1 class="hero-title"><?= htmlspecialchars($BRAND . ' | ' . $TITLE, ENT_QUOTES, 'UTF-8') ?></h1>

    <!-- BANNER -->
    <div class="banner-wrap">
      <span class="blade tl"></span>
      <span class="blade tr"></span>
      <span class="blade bl"></span>
      <span class="blade br"></span>
      <a href="<?= htmlspecialchars($LINK_DAFTAR) ?>" target="_blank" rel="nofollow noopener">
        <amp-img src="<?= htmlspecialchars($IMAGE) ?>"
                 alt="BANNER <?= htmlspecialchars($BRAND) ?>" width="545" height="613" layout="responsive"></amp-img>
      </a>
    </div>

    <!-- STAT STRIP — overlaps banner -->
    <div class="stat-strip">
      <div class="stat-box">
        <span class="stat-val">INSTAN</span>
        <span class="stat-lbl">Deposit</span>
      </div>
      <div class="stat-box">
        <span class="stat-val">24/7</span>
        <span class="stat-lbl">Nonstop</span>
      </div>
      <div class="stat-box">
        <span class="stat-val">&lt;2 MIN</span>
        <span class="stat-lbl">Withdraw</span>
      </div>
    </div>

    <!-- CTA BUTTONS — side by side -->
    <div class="cta-row">
      <a href="<?= htmlspecialchars($LINK_DAFTAR) ?>" class="cta cta-primary" target="_blank" rel="nofollow noopener">
        <svg class="cta-ico" viewBox="0 0 40 40" fill="currentColor"><use href="#i-pad"/></svg>
        LOGIN
      </a>
      <a href="<?= htmlspecialchars($LINK_DAFTAR) ?>" class="cta cta-secondary" target="_blank" rel="nofollow noopener">
        <svg class="cta-ico" viewBox="0 0 40 40" fill="currentColor"><use href="#i-user"/></svg>
        DAFTAR
      </a>
    </div>

    <!-- ALT LINK -->
    <a href="<?= htmlspecialchars($LINK_DAFTAR) ?>" class="alt-pill" target="_blank" rel="nofollow noopener">
      <svg viewBox="0 0 24 24"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
      Link Alternatif
    </a>

    <!-- DIVIDER -->
    <div class="divider">
      <span class="div-line"></span>
      <span class="div-text">Informasi</span>
      <span class="div-line"></span>
    </div>

    <!-- INFO CARDS -->
    <div class="cards">
      <div class="card">
        <div class="card-icon"><svg viewBox="0 0 40 40"><use href="#i-shield"/></svg></div>
        <div class="card-text">
          <div class="card-name">Situs Resmi <?= htmlspecialchars($BRAND) ?></div>
          <div class="card-desc">Halaman resmi dengan lisensi terpercaya & data terenkripsi SSL 256-bit</div>
        </div>
        <span class="card-badge">RESMI</span>
      </div>
      <div class="card">
        <div class="card-icon"><svg viewBox="0 0 40 40"><use href="#i-bolt"/></svg></div>
        <div class="card-text">
          <div class="card-name">Deposit Mulai 10.000</div>
          <div class="card-desc">Transfer via Bank, E-Wallet, atau QRIS — proses instan otomatis</div>
        </div>
        <span class="card-badge">10.000</span>
      </div>
    </div>

    <!-- TRUST BANNER -->
    <div class="trust-wrap">
      <amp-img alt="<?= htmlspecialchars($BRAND) ?> Terpercaya 100%" src="https://blogger.googleusercontent.com/img/a/AVvXsEi3M81rt_aKzhu94I-FmppDG3QZtyw8z8LgffhBEdYEh9rcTSH9Ti2QErE0CIOgg483VTHnLoVvoTxpPkbP9gH9u2uY85U4gb7iYUEdqe1p_rtQVGAZFlksdtWwM_I0FgkO1Jdw7dJPHPW6TJVDQ4_FBndByv2cW0UwOG8a9VcdgMNHeN43PfsgP95AQe89"
               width="1200" height="120" layout="responsive"></amp-img>
    </div>

    <!-- FOOTER -->
    <footer class="foot">
      <p>&copy; 2026 &bull; <?= htmlspecialchars($BRAND) ?> &bull; All Rights Reserved</p>
      <span class="sig"><?= htmlspecialchars($BRAND) ?></span>
    </footer>

  </div>
</div>

</body>
</html>